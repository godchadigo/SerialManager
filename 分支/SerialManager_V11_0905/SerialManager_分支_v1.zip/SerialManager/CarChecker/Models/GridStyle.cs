﻿using Sunny.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarChecker.Models
{
    public class GridStyle
    {
        public UIDataGridView Grid { get; set; }
        public UIStyle Style { get; set; }
    }
}
