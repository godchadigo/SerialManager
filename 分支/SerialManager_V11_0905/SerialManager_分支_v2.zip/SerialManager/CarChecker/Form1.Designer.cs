﻿namespace CarChecker
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle81 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle82 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle83 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle84 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle85 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle86 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle87 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle88 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle89 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle90 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle91 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle92 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle93 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle94 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle95 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle96 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle97 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle98 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle99 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle100 = new System.Windows.Forms.DataGridViewCellStyle();
            this.uiTabControl1 = new Sunny.UI.UITabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.uiTableLayoutPanel2 = new Sunny.UI.UITableLayoutPanel();
            this.uiPanel2 = new Sunny.UI.UIPanel();
            this.uiButton3 = new Sunny.UI.UIButton();
            this.uiButton2 = new Sunny.UI.UIButton();
            this.uiButton1 = new Sunny.UI.UIButton();
            this.StartReadStatus_btn = new Sunny.UI.UIButton();
            this.StopReadStatus_btn = new Sunny.UI.UIButton();
            this.uiPanel1 = new Sunny.UI.UIPanel();
            this.uiTableLayoutPanel3 = new Sunny.UI.UITableLayoutPanel();
            this.packetText_label = new Sunny.UI.UILabel();
            this.uiPanel7 = new Sunny.UI.UIPanel();
            this.Barcode_tBox = new Sunny.UI.UITextBox();
            this.uiLabel1 = new Sunny.UI.UILabel();
            this.uiTableLayoutPanel1 = new Sunny.UI.UITableLayoutPanel();
            this.uiPanel6 = new Sunny.UI.UIPanel();
            this.Right_Grid = new Sunny.UI.UIDataGridView();
            this.uiPanel5 = new Sunny.UI.UIPanel();
            this.Left_Grid = new Sunny.UI.UIDataGridView();
            this.uiPanel4 = new Sunny.UI.UIPanel();
            this.uiLabel3 = new Sunny.UI.UILabel();
            this.uiPanel3 = new Sunny.UI.UIPanel();
            this.uiLabel2 = new Sunny.UI.UILabel();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.uiTableLayoutPanel4 = new Sunny.UI.UITableLayoutPanel();
            this.Recode_Grid = new Sunny.UI.UIDataGridView();
            this.RawResultAdvance_Grid = new Sunny.UI.UIDataGridView();
            this.uiPanel8 = new Sunny.UI.UIPanel();
            this.QuereBarcode_tBox = new Sunny.UI.UITextBox();
            this.uiLabel6 = new Sunny.UI.UILabel();
            this.uiButton5 = new Sunny.UI.UIButton();
            this.uiDatePicker1 = new Sunny.UI.UIDatePicker();
            this.uiLabel5 = new Sunny.UI.UILabel();
            this.uiButton4 = new Sunny.UI.UIButton();
            this.uiPanel9 = new Sunny.UI.UIPanel();
            this.QueryDate_label = new Sunny.UI.UILabel();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.btnAllClose = new Sunny.UI.UIButton();
            this.btnAllOpen = new Sunny.UI.UIButton();
            this.btnStopReadStatus22 = new Sunny.UI.UIButton();
            this.btnStartReadStatus22 = new Sunny.UI.UIButton();
            this.uiTabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.uiTableLayoutPanel2.SuspendLayout();
            this.uiPanel2.SuspendLayout();
            this.uiPanel1.SuspendLayout();
            this.uiTableLayoutPanel3.SuspendLayout();
            this.uiPanel7.SuspendLayout();
            this.uiTableLayoutPanel1.SuspendLayout();
            this.uiPanel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Right_Grid)).BeginInit();
            this.uiPanel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Left_Grid)).BeginInit();
            this.uiPanel4.SuspendLayout();
            this.uiPanel3.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.uiTableLayoutPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Recode_Grid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.RawResultAdvance_Grid)).BeginInit();
            this.uiPanel8.SuspendLayout();
            this.uiPanel9.SuspendLayout();
            this.SuspendLayout();
            // 
            // uiTabControl1
            // 
            this.uiTabControl1.Controls.Add(this.tabPage1);
            this.uiTabControl1.Controls.Add(this.tabPage2);
            this.uiTabControl1.Controls.Add(this.tabPage3);
            this.uiTabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uiTabControl1.DrawMode = System.Windows.Forms.TabDrawMode.OwnerDrawFixed;
            this.uiTabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiTabControl1.Frame = null;
            this.uiTabControl1.ItemSize = new System.Drawing.Size(150, 40);
            this.uiTabControl1.Location = new System.Drawing.Point(0, 0);
            this.uiTabControl1.MainPage = "";
            this.uiTabControl1.Name = "uiTabControl1";
            this.uiTabControl1.SelectedIndex = 0;
            this.uiTabControl1.Size = new System.Drawing.Size(1904, 1001);
            this.uiTabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.uiTabControl1.TabIndex = 4;
            this.uiTabControl1.TipsFont = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiTabControl1.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.uiTableLayoutPanel2);
            this.tabPage1.Location = new System.Drawing.Point(0, 40);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Size = new System.Drawing.Size(1904, 961);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "採集頁";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // uiTableLayoutPanel2
            // 
            this.uiTableLayoutPanel2.ColumnCount = 2;
            this.uiTableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 78.04878F));
            this.uiTableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 21.95122F));
            this.uiTableLayoutPanel2.Controls.Add(this.uiPanel2, 1, 1);
            this.uiTableLayoutPanel2.Controls.Add(this.uiPanel1, 0, 0);
            this.uiTableLayoutPanel2.Controls.Add(this.uiTableLayoutPanel1, 0, 1);
            this.uiTableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uiTableLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.uiTableLayoutPanel2.Name = "uiTableLayoutPanel2";
            this.uiTableLayoutPanel2.RowCount = 2;
            this.uiTableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.uiTableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.uiTableLayoutPanel2.Size = new System.Drawing.Size(1904, 961);
            this.uiTableLayoutPanel2.TabIndex = 4;
            this.uiTableLayoutPanel2.TagString = null;
            // 
            // uiPanel2
            // 
            this.uiPanel2.Controls.Add(this.btnAllClose);
            this.uiPanel2.Controls.Add(this.btnAllOpen);
            this.uiPanel2.Controls.Add(this.btnStopReadStatus22);
            this.uiPanel2.Controls.Add(this.btnStartReadStatus22);
            this.uiPanel2.Controls.Add(this.uiButton3);
            this.uiPanel2.Controls.Add(this.uiButton2);
            this.uiPanel2.Controls.Add(this.uiButton1);
            this.uiPanel2.Controls.Add(this.StartReadStatus_btn);
            this.uiPanel2.Controls.Add(this.StopReadStatus_btn);
            this.uiPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uiPanel2.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiPanel2.Location = new System.Drawing.Point(1486, 96);
            this.uiPanel2.Margin = new System.Windows.Forms.Padding(0);
            this.uiPanel2.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPanel2.Name = "uiPanel2";
            this.uiPanel2.Radius = 0;
            this.uiPanel2.Size = new System.Drawing.Size(418, 865);
            this.uiPanel2.TabIndex = 1;
            this.uiPanel2.Text = " ";
            this.uiPanel2.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.uiPanel2.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // uiButton3
            // 
            this.uiButton3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.uiButton3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton3.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiButton3.Location = new System.Drawing.Point(6, 626);
            this.uiButton3.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiButton3.Name = "uiButton3";
            this.uiButton3.Size = new System.Drawing.Size(409, 44);
            this.uiButton3.TabIndex = 4;
            this.uiButton3.Text = "上傳結果";
            this.uiButton3.TipsFont = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiButton3.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            this.uiButton3.Click += new System.EventHandler(this.uiButton3_Click);
            // 
            // uiButton2
            // 
            this.uiButton2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.uiButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton2.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiButton2.Location = new System.Drawing.Point(6, 576);
            this.uiButton2.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiButton2.Name = "uiButton2";
            this.uiButton2.Size = new System.Drawing.Size(409, 44);
            this.uiButton2.TabIndex = 3;
            this.uiButton2.Text = "測試用2 不用管";
            this.uiButton2.TipsFont = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiButton2.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            this.uiButton2.Click += new System.EventHandler(this.button2_Click);
            // 
            // uiButton1
            // 
            this.uiButton1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.uiButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton1.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiButton1.Location = new System.Drawing.Point(6, 526);
            this.uiButton1.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiButton1.Name = "uiButton1";
            this.uiButton1.Size = new System.Drawing.Size(409, 44);
            this.uiButton1.TabIndex = 2;
            this.uiButton1.Text = "測試用 不用管";
            this.uiButton1.TipsFont = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiButton1.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            this.uiButton1.Click += new System.EventHandler(this.button1_Click);
            // 
            // StartReadStatus_btn
            // 
            this.StartReadStatus_btn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.StartReadStatus_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.StartReadStatus_btn.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.StartReadStatus_btn.Location = new System.Drawing.Point(6, 3);
            this.StartReadStatus_btn.MinimumSize = new System.Drawing.Size(1, 1);
            this.StartReadStatus_btn.Name = "StartReadStatus_btn";
            this.StartReadStatus_btn.Size = new System.Drawing.Size(409, 46);
            this.StartReadStatus_btn.TabIndex = 0;
            this.StartReadStatus_btn.Text = "開始讀取 按鍵狀態";
            this.StartReadStatus_btn.TipsFont = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.StartReadStatus_btn.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            this.StartReadStatus_btn.Click += new System.EventHandler(this.StartReadStatus_btn_Click);
            // 
            // StopReadStatus_btn
            // 
            this.StopReadStatus_btn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.StopReadStatus_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.StopReadStatus_btn.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.StopReadStatus_btn.Location = new System.Drawing.Point(6, 55);
            this.StopReadStatus_btn.MinimumSize = new System.Drawing.Size(1, 1);
            this.StopReadStatus_btn.Name = "StopReadStatus_btn";
            this.StopReadStatus_btn.Size = new System.Drawing.Size(409, 44);
            this.StopReadStatus_btn.TabIndex = 1;
            this.StopReadStatus_btn.Text = "結束讀取 按鍵狀態";
            this.StopReadStatus_btn.TipsFont = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.StopReadStatus_btn.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            this.StopReadStatus_btn.Click += new System.EventHandler(this.StopReadStatus_btn_Click);
            // 
            // uiPanel1
            // 
            this.uiTableLayoutPanel2.SetColumnSpan(this.uiPanel1, 2);
            this.uiPanel1.Controls.Add(this.uiTableLayoutPanel3);
            this.uiPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uiPanel1.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiPanel1.Location = new System.Drawing.Point(0, 0);
            this.uiPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.uiPanel1.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPanel1.Name = "uiPanel1";
            this.uiPanel1.Radius = 0;
            this.uiPanel1.Size = new System.Drawing.Size(1904, 96);
            this.uiPanel1.TabIndex = 0;
            this.uiPanel1.Text = " ";
            this.uiPanel1.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.uiPanel1.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // uiTableLayoutPanel3
            // 
            this.uiTableLayoutPanel3.ColumnCount = 1;
            this.uiTableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uiTableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.uiTableLayoutPanel3.Controls.Add(this.packetText_label, 0, 1);
            this.uiTableLayoutPanel3.Controls.Add(this.uiPanel7, 0, 0);
            this.uiTableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uiTableLayoutPanel3.Location = new System.Drawing.Point(0, 0);
            this.uiTableLayoutPanel3.Name = "uiTableLayoutPanel3";
            this.uiTableLayoutPanel3.RowCount = 2;
            this.uiTableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.uiTableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.uiTableLayoutPanel3.Size = new System.Drawing.Size(1904, 96);
            this.uiTableLayoutPanel3.TabIndex = 0;
            this.uiTableLayoutPanel3.TagString = null;
            // 
            // packetText_label
            // 
            this.packetText_label.BackColor = System.Drawing.Color.Transparent;
            this.packetText_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.packetText_label.Location = new System.Drawing.Point(3, 48);
            this.packetText_label.Name = "packetText_label";
            this.packetText_label.Size = new System.Drawing.Size(1898, 48);
            this.packetText_label.TabIndex = 1;
            this.packetText_label.Text = "報文內容 : ";
            this.packetText_label.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.packetText_label.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // uiPanel7
            // 
            this.uiPanel7.Controls.Add(this.Barcode_tBox);
            this.uiPanel7.Controls.Add(this.uiLabel1);
            this.uiPanel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uiPanel7.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiPanel7.Location = new System.Drawing.Point(1, 1);
            this.uiPanel7.Margin = new System.Windows.Forms.Padding(1);
            this.uiPanel7.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPanel7.Name = "uiPanel7";
            this.uiPanel7.Size = new System.Drawing.Size(1902, 46);
            this.uiPanel7.TabIndex = 2;
            this.uiPanel7.Text = "uiPanel7";
            this.uiPanel7.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.uiPanel7.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // Barcode_tBox
            // 
            this.Barcode_tBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Barcode_tBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Barcode_tBox.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.Barcode_tBox.Location = new System.Drawing.Point(164, 0);
            this.Barcode_tBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Barcode_tBox.MinimumSize = new System.Drawing.Size(1, 16);
            this.Barcode_tBox.Name = "Barcode_tBox";
            this.Barcode_tBox.ShowText = false;
            this.Barcode_tBox.Size = new System.Drawing.Size(1738, 46);
            this.Barcode_tBox.TabIndex = 3;
            this.Barcode_tBox.Text = "Barcode Context";
            this.Barcode_tBox.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Barcode_tBox.Watermark = "";
            this.Barcode_tBox.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            this.Barcode_tBox.Click += new System.EventHandler(this.Barcode_tBox_Click);
            // 
            // uiLabel1
            // 
            this.uiLabel1.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.uiLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiLabel1.Location = new System.Drawing.Point(0, 0);
            this.uiLabel1.Name = "uiLabel1";
            this.uiLabel1.Size = new System.Drawing.Size(164, 46);
            this.uiLabel1.TabIndex = 2;
            this.uiLabel1.Text = "組別編號 : ";
            this.uiLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.uiLabel1.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // uiTableLayoutPanel1
            // 
            this.uiTableLayoutPanel1.ColumnCount = 2;
            this.uiTableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.uiTableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.uiTableLayoutPanel1.Controls.Add(this.uiPanel6, 1, 1);
            this.uiTableLayoutPanel1.Controls.Add(this.uiPanel5, 0, 1);
            this.uiTableLayoutPanel1.Controls.Add(this.uiPanel4, 1, 0);
            this.uiTableLayoutPanel1.Controls.Add(this.uiPanel3, 0, 0);
            this.uiTableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uiTableLayoutPanel1.Location = new System.Drawing.Point(0, 96);
            this.uiTableLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.uiTableLayoutPanel1.Name = "uiTableLayoutPanel1";
            this.uiTableLayoutPanel1.RowCount = 2;
            this.uiTableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.uiTableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.uiTableLayoutPanel1.Size = new System.Drawing.Size(1486, 865);
            this.uiTableLayoutPanel1.TabIndex = 2;
            this.uiTableLayoutPanel1.TagString = null;
            // 
            // uiPanel6
            // 
            this.uiPanel6.Controls.Add(this.Right_Grid);
            this.uiPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uiPanel6.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiPanel6.Location = new System.Drawing.Point(743, 86);
            this.uiPanel6.Margin = new System.Windows.Forms.Padding(0);
            this.uiPanel6.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPanel6.Name = "uiPanel6";
            this.uiPanel6.Size = new System.Drawing.Size(743, 779);
            this.uiPanel6.TabIndex = 3;
            this.uiPanel6.Text = " ";
            this.uiPanel6.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.uiPanel6.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // Right_Grid
            // 
            dataGridViewCellStyle81.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.Right_Grid.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle81;
            this.Right_Grid.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.Right_Grid.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle82.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle82.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle82.Font = new System.Drawing.Font("微软雅黑", 12F);
            dataGridViewCellStyle82.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle82.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle82.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle82.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Right_Grid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle82;
            this.Right_Grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle83.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle83.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle83.Font = new System.Drawing.Font("微软雅黑", 12F);
            dataGridViewCellStyle83.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle83.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle83.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle83.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.Right_Grid.DefaultCellStyle = dataGridViewCellStyle83;
            this.Right_Grid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Right_Grid.EnableHeadersVisualStyles = false;
            this.Right_Grid.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.Right_Grid.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(173)))), ((int)(((byte)(255)))));
            this.Right_Grid.Location = new System.Drawing.Point(0, 0);
            this.Right_Grid.Margin = new System.Windows.Forms.Padding(0);
            this.Right_Grid.Name = "Right_Grid";
            dataGridViewCellStyle84.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle84.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle84.Font = new System.Drawing.Font("微软雅黑", 12F);
            dataGridViewCellStyle84.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle84.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle84.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle84.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Right_Grid.RowHeadersDefaultCellStyle = dataGridViewCellStyle84;
            dataGridViewCellStyle85.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle85.Font = new System.Drawing.Font("微软雅黑", 12F);
            dataGridViewCellStyle85.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle85.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle85.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Right_Grid.RowsDefaultCellStyle = dataGridViewCellStyle85;
            this.Right_Grid.RowTemplate.Height = 24;
            this.Right_Grid.ScrollBarRectColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.Right_Grid.SelectedIndex = -1;
            this.Right_Grid.Size = new System.Drawing.Size(743, 779);
            this.Right_Grid.TabIndex = 1;
            this.Right_Grid.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            this.Right_Grid.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Right_Grid_CellDoubleClick);
            this.Right_Grid.Click += new System.EventHandler(this.Right_Grid_Click);
            // 
            // uiPanel5
            // 
            this.uiPanel5.Controls.Add(this.Left_Grid);
            this.uiPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uiPanel5.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiPanel5.Location = new System.Drawing.Point(0, 86);
            this.uiPanel5.Margin = new System.Windows.Forms.Padding(0);
            this.uiPanel5.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPanel5.Name = "uiPanel5";
            this.uiPanel5.Size = new System.Drawing.Size(743, 779);
            this.uiPanel5.TabIndex = 2;
            this.uiPanel5.Text = " ";
            this.uiPanel5.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.uiPanel5.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // Left_Grid
            // 
            dataGridViewCellStyle86.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.Left_Grid.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle86;
            this.Left_Grid.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.Left_Grid.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle87.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle87.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle87.Font = new System.Drawing.Font("微软雅黑", 12F);
            dataGridViewCellStyle87.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle87.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle87.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle87.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Left_Grid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle87;
            this.Left_Grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle88.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle88.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle88.Font = new System.Drawing.Font("微软雅黑", 12F);
            dataGridViewCellStyle88.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle88.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle88.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle88.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.Left_Grid.DefaultCellStyle = dataGridViewCellStyle88;
            this.Left_Grid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Left_Grid.EnableHeadersVisualStyles = false;
            this.Left_Grid.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.Left_Grid.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(173)))), ((int)(((byte)(255)))));
            this.Left_Grid.Location = new System.Drawing.Point(0, 0);
            this.Left_Grid.Margin = new System.Windows.Forms.Padding(0);
            this.Left_Grid.Name = "Left_Grid";
            dataGridViewCellStyle89.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle89.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle89.Font = new System.Drawing.Font("微软雅黑", 12F);
            dataGridViewCellStyle89.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle89.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle89.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle89.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Left_Grid.RowHeadersDefaultCellStyle = dataGridViewCellStyle89;
            dataGridViewCellStyle90.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle90.Font = new System.Drawing.Font("微软雅黑", 12F);
            dataGridViewCellStyle90.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle90.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle90.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Left_Grid.RowsDefaultCellStyle = dataGridViewCellStyle90;
            this.Left_Grid.RowTemplate.Height = 24;
            this.Left_Grid.ScrollBarRectColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.Left_Grid.SelectedIndex = -1;
            this.Left_Grid.Size = new System.Drawing.Size(743, 779);
            this.Left_Grid.TabIndex = 0;
            this.Left_Grid.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // uiPanel4
            // 
            this.uiPanel4.Controls.Add(this.uiLabel3);
            this.uiPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uiPanel4.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiPanel4.Location = new System.Drawing.Point(743, 0);
            this.uiPanel4.Margin = new System.Windows.Forms.Padding(0);
            this.uiPanel4.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPanel4.Name = "uiPanel4";
            this.uiPanel4.Radius = 0;
            this.uiPanel4.Size = new System.Drawing.Size(743, 86);
            this.uiPanel4.TabIndex = 1;
            this.uiPanel4.Text = " ";
            this.uiPanel4.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.uiPanel4.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // uiLabel3
            // 
            this.uiLabel3.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uiLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiLabel3.Location = new System.Drawing.Point(0, 0);
            this.uiLabel3.Name = "uiLabel3";
            this.uiLabel3.Size = new System.Drawing.Size(743, 86);
            this.uiLabel3.TabIndex = 1;
            this.uiLabel3.Text = "量測中結果";
            this.uiLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.uiLabel3.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // uiPanel3
            // 
            this.uiPanel3.Controls.Add(this.uiLabel2);
            this.uiPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uiPanel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiPanel3.Location = new System.Drawing.Point(0, 0);
            this.uiPanel3.Margin = new System.Windows.Forms.Padding(0);
            this.uiPanel3.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPanel3.Name = "uiPanel3";
            this.uiPanel3.Padding = new System.Windows.Forms.Padding(3);
            this.uiPanel3.Radius = 0;
            this.uiPanel3.Size = new System.Drawing.Size(743, 86);
            this.uiPanel3.TabIndex = 0;
            this.uiPanel3.Text = " ";
            this.uiPanel3.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.uiPanel3.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // uiLabel2
            // 
            this.uiLabel2.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uiLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiLabel2.Location = new System.Drawing.Point(3, 3);
            this.uiLabel2.Name = "uiLabel2";
            this.uiLabel2.Size = new System.Drawing.Size(737, 80);
            this.uiLabel2.TabIndex = 0;
            this.uiLabel2.Text = "測量內容";
            this.uiLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.uiLabel2.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.uiTableLayoutPanel4);
            this.tabPage2.Location = new System.Drawing.Point(0, 40);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Size = new System.Drawing.Size(200, 60);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "數據查詢頁";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // uiTableLayoutPanel4
            // 
            this.uiTableLayoutPanel4.ColumnCount = 2;
            this.uiTableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 66.66666F));
            this.uiTableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.uiTableLayoutPanel4.Controls.Add(this.Recode_Grid, 0, 1);
            this.uiTableLayoutPanel4.Controls.Add(this.RawResultAdvance_Grid, 1, 1);
            this.uiTableLayoutPanel4.Controls.Add(this.uiPanel8, 0, 0);
            this.uiTableLayoutPanel4.Controls.Add(this.uiPanel9, 1, 0);
            this.uiTableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uiTableLayoutPanel4.Location = new System.Drawing.Point(0, 0);
            this.uiTableLayoutPanel4.Name = "uiTableLayoutPanel4";
            this.uiTableLayoutPanel4.RowCount = 2;
            this.uiTableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.989594F));
            this.uiTableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90.01041F));
            this.uiTableLayoutPanel4.Size = new System.Drawing.Size(200, 60);
            this.uiTableLayoutPanel4.TabIndex = 0;
            this.uiTableLayoutPanel4.TagString = null;
            // 
            // Recode_Grid
            // 
            dataGridViewCellStyle91.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.Recode_Grid.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle91;
            this.Recode_Grid.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.Recode_Grid.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle92.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle92.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle92.Font = new System.Drawing.Font("微软雅黑", 12F);
            dataGridViewCellStyle92.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle92.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle92.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle92.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Recode_Grid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle92;
            this.Recode_Grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle93.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle93.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle93.Font = new System.Drawing.Font("微软雅黑", 12F);
            dataGridViewCellStyle93.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle93.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle93.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle93.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.Recode_Grid.DefaultCellStyle = dataGridViewCellStyle93;
            this.Recode_Grid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Recode_Grid.EnableHeadersVisualStyles = false;
            this.Recode_Grid.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.Recode_Grid.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(173)))), ((int)(((byte)(255)))));
            this.Recode_Grid.Location = new System.Drawing.Point(0, 5);
            this.Recode_Grid.Margin = new System.Windows.Forms.Padding(0);
            this.Recode_Grid.Name = "Recode_Grid";
            dataGridViewCellStyle94.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle94.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle94.Font = new System.Drawing.Font("微软雅黑", 12F);
            dataGridViewCellStyle94.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle94.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle94.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle94.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Recode_Grid.RowHeadersDefaultCellStyle = dataGridViewCellStyle94;
            dataGridViewCellStyle95.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle95.Font = new System.Drawing.Font("微软雅黑", 12F);
            dataGridViewCellStyle95.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle95.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle95.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Recode_Grid.RowsDefaultCellStyle = dataGridViewCellStyle95;
            this.Recode_Grid.RowTemplate.Height = 24;
            this.Recode_Grid.ScrollBarRectColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.Recode_Grid.SelectedIndex = -1;
            this.Recode_Grid.Size = new System.Drawing.Size(133, 55);
            this.Recode_Grid.TabIndex = 0;
            this.Recode_Grid.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            this.Recode_Grid.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Recode_Grid_CellClick);
            // 
            // RawResultAdvance_Grid
            // 
            dataGridViewCellStyle96.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.RawResultAdvance_Grid.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle96;
            this.RawResultAdvance_Grid.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.RawResultAdvance_Grid.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle97.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle97.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle97.Font = new System.Drawing.Font("微软雅黑", 12F);
            dataGridViewCellStyle97.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle97.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle97.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle97.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.RawResultAdvance_Grid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle97;
            this.RawResultAdvance_Grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle98.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle98.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle98.Font = new System.Drawing.Font("微软雅黑", 12F);
            dataGridViewCellStyle98.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle98.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle98.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle98.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.RawResultAdvance_Grid.DefaultCellStyle = dataGridViewCellStyle98;
            this.RawResultAdvance_Grid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.RawResultAdvance_Grid.EnableHeadersVisualStyles = false;
            this.RawResultAdvance_Grid.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.RawResultAdvance_Grid.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(173)))), ((int)(((byte)(255)))));
            this.RawResultAdvance_Grid.Location = new System.Drawing.Point(134, 6);
            this.RawResultAdvance_Grid.Margin = new System.Windows.Forms.Padding(1);
            this.RawResultAdvance_Grid.Name = "RawResultAdvance_Grid";
            dataGridViewCellStyle99.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle99.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle99.Font = new System.Drawing.Font("微软雅黑", 12F);
            dataGridViewCellStyle99.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle99.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle99.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle99.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.RawResultAdvance_Grid.RowHeadersDefaultCellStyle = dataGridViewCellStyle99;
            dataGridViewCellStyle100.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle100.Font = new System.Drawing.Font("微软雅黑", 12F);
            dataGridViewCellStyle100.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle100.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle100.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.RawResultAdvance_Grid.RowsDefaultCellStyle = dataGridViewCellStyle100;
            this.RawResultAdvance_Grid.RowTemplate.Height = 24;
            this.RawResultAdvance_Grid.ScrollBarRectColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.RawResultAdvance_Grid.SelectedIndex = -1;
            this.RawResultAdvance_Grid.Size = new System.Drawing.Size(65, 53);
            this.RawResultAdvance_Grid.TabIndex = 1;
            this.RawResultAdvance_Grid.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // uiPanel8
            // 
            this.uiPanel8.Controls.Add(this.QuereBarcode_tBox);
            this.uiPanel8.Controls.Add(this.uiLabel6);
            this.uiPanel8.Controls.Add(this.uiButton5);
            this.uiPanel8.Controls.Add(this.uiDatePicker1);
            this.uiPanel8.Controls.Add(this.uiLabel5);
            this.uiPanel8.Controls.Add(this.uiButton4);
            this.uiPanel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uiPanel8.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiPanel8.Location = new System.Drawing.Point(1, 1);
            this.uiPanel8.Margin = new System.Windows.Forms.Padding(1);
            this.uiPanel8.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPanel8.Name = "uiPanel8";
            this.uiPanel8.Size = new System.Drawing.Size(131, 3);
            this.uiPanel8.TabIndex = 2;
            this.uiPanel8.Text = " ";
            this.uiPanel8.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.uiPanel8.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // QuereBarcode_tBox
            // 
            this.QuereBarcode_tBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.QuereBarcode_tBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.QuereBarcode_tBox.Location = new System.Drawing.Point(853, 16);
            this.QuereBarcode_tBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.QuereBarcode_tBox.MinimumSize = new System.Drawing.Size(1, 16);
            this.QuereBarcode_tBox.Name = "QuereBarcode_tBox";
            this.QuereBarcode_tBox.ShowText = false;
            this.QuereBarcode_tBox.Size = new System.Drawing.Size(254, 60);
            this.QuereBarcode_tBox.TabIndex = 5;
            this.QuereBarcode_tBox.Text = "!!請輸入辨識碼!!";
            this.QuereBarcode_tBox.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.QuereBarcode_tBox.Watermark = "";
            this.QuereBarcode_tBox.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            this.QuereBarcode_tBox.Click += new System.EventHandler(this.QuereBarcode_tBox_Click);
            // 
            // uiLabel6
            // 
            this.uiLabel6.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiLabel6.Location = new System.Drawing.Point(576, 1);
            this.uiLabel6.Name = "uiLabel6";
            this.uiLabel6.Size = new System.Drawing.Size(295, 94);
            this.uiLabel6.TabIndex = 4;
            this.uiLabel6.Text = "選擇查詢Barcode :";
            this.uiLabel6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.uiLabel6.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // uiButton5
            // 
            this.uiButton5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton5.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiButton5.Location = new System.Drawing.Point(1114, 7);
            this.uiButton5.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiButton5.Name = "uiButton5";
            this.uiButton5.Radius = 0;
            this.uiButton5.Size = new System.Drawing.Size(149, 79);
            this.uiButton5.TabIndex = 3;
            this.uiButton5.Text = "查詢辨識碼";
            this.uiButton5.TipsFont = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiButton5.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            this.uiButton5.Click += new System.EventHandler(this.uiButton5_Click);
            // 
            // uiDatePicker1
            // 
            this.uiDatePicker1.FillColor = System.Drawing.Color.White;
            this.uiDatePicker1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiDatePicker1.Location = new System.Drawing.Point(225, 6);
            this.uiDatePicker1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiDatePicker1.MaxLength = 10;
            this.uiDatePicker1.MinimumSize = new System.Drawing.Size(63, 0);
            this.uiDatePicker1.Name = "uiDatePicker1";
            this.uiDatePicker1.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.uiDatePicker1.Size = new System.Drawing.Size(180, 79);
            this.uiDatePicker1.SymbolDropDown = 61555;
            this.uiDatePicker1.SymbolNormal = 61555;
            this.uiDatePicker1.TabIndex = 2;
            this.uiDatePicker1.Text = "2022-09-04";
            this.uiDatePicker1.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.uiDatePicker1.Value = new System.DateTime(2022, 9, 4, 23, 19, 55, 146);
            this.uiDatePicker1.Watermark = "";
            this.uiDatePicker1.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // uiLabel5
            // 
            this.uiLabel5.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiLabel5.Location = new System.Drawing.Point(0, 0);
            this.uiLabel5.Name = "uiLabel5";
            this.uiLabel5.Size = new System.Drawing.Size(225, 94);
            this.uiLabel5.TabIndex = 1;
            this.uiLabel5.Text = "選擇查詢日期 :";
            this.uiLabel5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.uiLabel5.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // uiButton4
            // 
            this.uiButton4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiButton4.Location = new System.Drawing.Point(412, 6);
            this.uiButton4.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiButton4.Name = "uiButton4";
            this.uiButton4.Radius = 0;
            this.uiButton4.Size = new System.Drawing.Size(138, 79);
            this.uiButton4.TabIndex = 0;
            this.uiButton4.Text = "查詢日期";
            this.uiButton4.TipsFont = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiButton4.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            this.uiButton4.Click += new System.EventHandler(this.uiButton4_Click);
            // 
            // uiPanel9
            // 
            this.uiPanel9.Controls.Add(this.QueryDate_label);
            this.uiPanel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uiPanel9.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiPanel9.Location = new System.Drawing.Point(134, 1);
            this.uiPanel9.Margin = new System.Windows.Forms.Padding(1);
            this.uiPanel9.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPanel9.Name = "uiPanel9";
            this.uiPanel9.Size = new System.Drawing.Size(65, 3);
            this.uiPanel9.TabIndex = 3;
            this.uiPanel9.Text = " ";
            this.uiPanel9.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.uiPanel9.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // QueryDate_label
            // 
            this.QueryDate_label.Dock = System.Windows.Forms.DockStyle.Fill;
            this.QueryDate_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.QueryDate_label.Location = new System.Drawing.Point(0, 0);
            this.QueryDate_label.Name = "QueryDate_label";
            this.QueryDate_label.Size = new System.Drawing.Size(65, 3);
            this.QueryDate_label.TabIndex = 1;
            this.QueryDate_label.Text = " ";
            this.QueryDate_label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.QueryDate_label.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // tabPage3
            // 
            this.tabPage3.Location = new System.Drawing.Point(0, 40);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(200, 60);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "設置頁";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // btnAllClose
            // 
            this.btnAllClose.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnAllClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAllClose.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.btnAllClose.Location = new System.Drawing.Point(3, 401);
            this.btnAllClose.MinimumSize = new System.Drawing.Size(1, 1);
            this.btnAllClose.Name = "btnAllClose";
            this.btnAllClose.Size = new System.Drawing.Size(409, 44);
            this.btnAllClose.TabIndex = 12;
            this.btnAllClose.Text = "交叉结束";
            this.btnAllClose.TipsFont = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnAllClose.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            this.btnAllClose.Click += new System.EventHandler(this.btnAllClose_Click);
            // 
            // btnAllOpen
            // 
            this.btnAllOpen.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnAllOpen.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAllOpen.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.btnAllOpen.Location = new System.Drawing.Point(2, 322);
            this.btnAllOpen.MinimumSize = new System.Drawing.Size(1, 1);
            this.btnAllOpen.Name = "btnAllOpen";
            this.btnAllOpen.Size = new System.Drawing.Size(409, 44);
            this.btnAllOpen.TabIndex = 11;
            this.btnAllOpen.Text = "交叉开始";
            this.btnAllOpen.TipsFont = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnAllOpen.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            this.btnAllOpen.Click += new System.EventHandler(this.btnAllOpen_Click);
            // 
            // btnStopReadStatus22
            // 
            this.btnStopReadStatus22.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnStopReadStatus22.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnStopReadStatus22.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.btnStopReadStatus22.Location = new System.Drawing.Point(3, 242);
            this.btnStopReadStatus22.MinimumSize = new System.Drawing.Size(1, 1);
            this.btnStopReadStatus22.Name = "btnStopReadStatus22";
            this.btnStopReadStatus22.Size = new System.Drawing.Size(409, 44);
            this.btnStopReadStatus22.TabIndex = 10;
            this.btnStopReadStatus22.Text = "22座椅面板测试完成";
            this.btnStopReadStatus22.TipsFont = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnStopReadStatus22.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            this.btnStopReadStatus22.Click += new System.EventHandler(this.btnStopReadStatus22_Click);
            // 
            // btnStartReadStatus22
            // 
            this.btnStartReadStatus22.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnStartReadStatus22.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnStartReadStatus22.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.btnStartReadStatus22.Location = new System.Drawing.Point(3, 183);
            this.btnStartReadStatus22.MinimumSize = new System.Drawing.Size(1, 1);
            this.btnStartReadStatus22.Name = "btnStartReadStatus22";
            this.btnStartReadStatus22.Size = new System.Drawing.Size(409, 44);
            this.btnStartReadStatus22.TabIndex = 9;
            this.btnStartReadStatus22.Text = "22座椅面板测试开始";
            this.btnStartReadStatus22.TipsFont = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnStartReadStatus22.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            this.btnStartReadStatus22.Click += new System.EventHandler(this.btnStartReadStatus22_Click);
            // 
            // Form1
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(1904, 1001);
            this.Controls.Add(this.uiTabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Resize += new System.EventHandler(this.Form1_Resize);
            this.uiTabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.uiTableLayoutPanel2.ResumeLayout(false);
            this.uiPanel2.ResumeLayout(false);
            this.uiPanel1.ResumeLayout(false);
            this.uiTableLayoutPanel3.ResumeLayout(false);
            this.uiPanel7.ResumeLayout(false);
            this.uiTableLayoutPanel1.ResumeLayout(false);
            this.uiPanel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Right_Grid)).EndInit();
            this.uiPanel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Left_Grid)).EndInit();
            this.uiPanel4.ResumeLayout(false);
            this.uiPanel3.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.uiTableLayoutPanel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Recode_Grid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.RawResultAdvance_Grid)).EndInit();
            this.uiPanel8.ResumeLayout(false);
            this.uiPanel9.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Sunny.UI.UITabControl uiTabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private Sunny.UI.UITableLayoutPanel uiTableLayoutPanel2;
        private Sunny.UI.UIPanel uiPanel2;
        private Sunny.UI.UIButton StartReadStatus_btn;
        private Sunny.UI.UIButton StopReadStatus_btn;
        private Sunny.UI.UIPanel uiPanel1;
        private Sunny.UI.UITableLayoutPanel uiTableLayoutPanel1;
        private Sunny.UI.UIPanel uiPanel6;
        private Sunny.UI.UIDataGridView Right_Grid;
        private Sunny.UI.UIPanel uiPanel5;
        private Sunny.UI.UIDataGridView Left_Grid;
        private Sunny.UI.UIPanel uiPanel4;
        private Sunny.UI.UILabel uiLabel3;
        private Sunny.UI.UIPanel uiPanel3;
        private Sunny.UI.UILabel uiLabel2;
        private System.Windows.Forms.TabPage tabPage2;
        private Sunny.UI.UIButton uiButton2;
        private Sunny.UI.UIButton uiButton1;
        private Sunny.UI.UILabel packetText_label;
        private System.Windows.Forms.TabPage tabPage3;
        private Sunny.UI.UIButton uiButton3;
        private Sunny.UI.UITableLayoutPanel uiTableLayoutPanel3;
        private Sunny.UI.UIPanel uiPanel7;
        private Sunny.UI.UITextBox Barcode_tBox;
        private Sunny.UI.UILabel uiLabel1;
        private Sunny.UI.UITableLayoutPanel uiTableLayoutPanel4;
        private Sunny.UI.UIDataGridView Recode_Grid;
        private Sunny.UI.UIDataGridView RawResultAdvance_Grid;
        private Sunny.UI.UIPanel uiPanel8;
        private Sunny.UI.UIPanel uiPanel9;
        private Sunny.UI.UILabel QueryDate_label;
        private Sunny.UI.UIButton uiButton4;
        private Sunny.UI.UIDatePicker uiDatePicker1;
        private Sunny.UI.UILabel uiLabel5;
        private Sunny.UI.UITextBox QuereBarcode_tBox;
        private Sunny.UI.UILabel uiLabel6;
        private Sunny.UI.UIButton uiButton5;
        private Sunny.UI.UIButton btnAllClose;
        private Sunny.UI.UIButton btnAllOpen;
        private Sunny.UI.UIButton btnStopReadStatus22;
        private Sunny.UI.UIButton btnStartReadStatus22;
    }
}

