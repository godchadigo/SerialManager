﻿using CarChecker.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarChecker.Models.Checks
{
    public class VoltButtonCheckModel : ICheckModel
    {        
        public int VoltValue { get; set; }        
        public int ButtonID { get; set; }
    }
}
